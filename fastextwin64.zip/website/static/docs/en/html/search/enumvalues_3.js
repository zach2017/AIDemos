var searchData=
[
  ['ns',['ns',['../namespacefasttext.html#a1ba04862fd670674501ccacc936e1952af01a37d157918910f2035b2af81ea4e1',1,'fasttext']]]
];
