var searchData=
[
  ['centroids_5f',['centroids_',['../classfasttext_1_1ProductQuantizer.html#a56ed1ae67f47e95f2d1f4c6146d4913a',1,'fasttext::ProductQuantizer']]],
  ['codes',['codes',['../classfasttext_1_1Model.html#ab6675d265df22787dfa9835196300d3b',1,'fasttext::Model']]],
  ['codes_5f',['codes_',['../classfasttext_1_1QMatrix.html#acc957d3d66b58cb9381f6a0556096c93',1,'fasttext::QMatrix']]],
  ['codesize_5f',['codesize_',['../classfasttext_1_1QMatrix.html#a4a69f60ba96c0b1a9da22c3951eca759',1,'fasttext::QMatrix']]],
  ['count',['count',['../structfasttext_1_1entry.html#ab1f793678a1669b826d48f8b9ddcee6a',1,'fasttext::entry::count()'],['../structfasttext_1_1Node.html#a76430b0ffbb3b8f217435b11e4f51118',1,'fasttext::Node::count()']]],
  ['cutoff',['cutoff',['../classfasttext_1_1Args.html#aecc2b6243e3fa7c8da1b6d1205da8df0',1,'fasttext::Args']]]
];
