var searchData=
[
  ['label',['label',['../namespacefasttext.html#a532eedeee97e8d66a96b519d165f4eb7ad304ba20e96d87411588eeabac850e34',1,'fasttext']]]
];
